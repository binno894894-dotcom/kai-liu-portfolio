let currentLang = "zh";

const TEXTS = {
  zh: {
    status: "防護全面啟動中",
    feat_story: "隱身看限動 (Ghost Stories)",
    feat_dm: "防私訊已讀 (Ghost DM)",
    feat_ads: "去除廣告推薦 (AdBlock)",
    feat_mute: "影音預設靜音 (Mute Audio)",
    feat_dl: "高清原檔下載 (Downloader)",
    active: "啟用",
    inactive: "停用",
    stat_story: "攔截限動",
    stat_dm: "攔截私訊",
    stat_ads: "過濾廣告",
    info: "💡 <strong>網頁版操作提示：</strong><br>進入 Instagram 頁面後，右下角會出現 <strong>👻 懸浮中控按鈕</strong>，可隨時自訂開關各項功能，並一鍵下載貼文與限動最高畫質圖片及影片！",
    open_ig: "開啟 Instagram 網頁版",
    lang_toggle: "EN"
  },
  en: {
    status: "Protection Fully Active",
    feat_story: "Ghost Stories (Unseen)",
    feat_dm: "Ghost DM (Unread Receipts)",
    feat_ads: "Block Ads & Suggestions",
    feat_mute: "Default Audio Mute",
    feat_dl: "HD Media Downloader",
    active: "ON",
    inactive: "OFF",
    stat_story: "Stories Blocked",
    stat_dm: "DMs Blocked",
    stat_ads: "Ads Filtered",
    info: "💡 <strong>Tip for Web:</strong><br>Inside Instagram, click the floating <strong>👻 Ghost button</strong> at the bottom right to customize toggles and download HD media!",
    open_ig: "Open Instagram Web",
    lang_toggle: "中文"
  }
};

function applyLang(lang) {
  currentLang = lang;
  const t = TEXTS[lang];
  document.getElementById("txt-status").textContent = t.status;
  document.getElementById("feat-story").textContent = t.feat_story;
  document.getElementById("feat-dm").textContent = t.feat_dm;
  document.getElementById("feat-ads").textContent = t.feat_ads;
  document.getElementById("feat-mute").textContent = t.feat_mute;
  document.getElementById("feat-dl").textContent = t.feat_dl;
  document.getElementById("lbl-stat-story").textContent = t.stat_story;
  document.getElementById("lbl-stat-dm").textContent = t.stat_dm;
  document.getElementById("lbl-stat-ads").textContent = t.stat_ads;
  document.getElementById("txt-info").innerHTML = t.info;
  document.getElementById("btn-open-ig").textContent = t.open_ig;
  document.getElementById("btn-lang").textContent = t.lang_toggle;
  try {
    localStorage.setItem("ghostgram_popup_lang", lang);
  } catch (_) {}
}

document.getElementById("btn-lang").addEventListener("click", () => {
  applyLang(currentLang === "zh" ? "en" : "zh");
});

try {
  const savedLang = localStorage.getItem("ghostgram_popup_lang");
  if (savedLang) applyLang(savedLang);
} catch (_) {}

// Sync stats from current tab if on Instagram
try {
  if (typeof chrome !== "undefined" && chrome.tabs && chrome.scripting) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes("instagram.com")) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            try {
              const raw = localStorage.getItem("ghostgram_config");
              return raw ? JSON.parse(raw) : null;
            } catch (_) { return null; }
          }
        }, (results) => {
          if (results && results[0] && results[0].result) {
            const conf = results[0].result;
            if (conf.storyBlocked !== undefined) document.getElementById("stat-story").textContent = conf.storyBlocked;
            if (conf.dmBlocked !== undefined) document.getElementById("stat-dm").textContent = conf.dmBlocked;
            if (conf.adsBlocked !== undefined) document.getElementById("stat-ads").textContent = conf.adsBlocked;

            if (conf.ghostStories === false) document.getElementById("badge-story").textContent = currentLang === "zh" ? "停用" : "OFF";
            if (conf.ghostDm === false) document.getElementById("badge-dm").textContent = currentLang === "zh" ? "停用" : "OFF";
            if (conf.blockAds === false) document.getElementById("badge-ads").textContent = currentLang === "zh" ? "停用" : "OFF";
            if (conf.defaultMute === false) document.getElementById("badge-mute").textContent = currentLang === "zh" ? "停用" : "OFF";
            if (conf.enableDownloader === false) document.getElementById("badge-dl").textContent = currentLang === "zh" ? "停用" : "OFF";
          }
        });
      }
    });
  }
} catch (_) {}

