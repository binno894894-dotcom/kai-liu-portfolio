# Chrome Web Store Listing — GhostGram

> Last Updated: 2026-10-12

## Store Listing

**Extension Name** [REQUIRED]
GhostGram — Instagram 隱身模式與增強套件

**Short Description** [REQUIRED]
無痕觀看 Instagram 限動與私訊、自動過濾廣告、影音預設靜音、高清照片影片一鍵下載。
(英文版可填: Anonymous story & DM viewing for Instagram, ad blocking, default mute, and HD media downloader.)

**Detailed Description** [REQUIRED]
GhostGram 是專為 Instagram 網頁版打造的隱私守護與瀏覽增強工具，讓您在探索社群時享有完整的無痕自由與清爽體驗。

【核心功能】
• 🟣 隱身看限動：觀看限時動態時不留下已看紀錄，名單永遠無蹤跡。
• 🔵 防私訊已讀：開啟聊天室檢視訊息不觸發已讀標記，從容回覆無壓力。
• 🟢 去除贊助廣告：自動過濾動態牆廣告與算法推薦追蹤，享受純淨版面。
• 🔇 影音預設靜音：載入貼文與限動時自動靜音，防止公共場合突發爆音。
• 📥 高清原檔下載：貼文與限動播放器內皆有一鍵下載按鈕，輕鬆保存最高畫質原圖與 MP4 影片。
• ⏸️ 限動自由定格：支援空白鍵暫停與繼續播放限動，防止自動跳頁過快。
• 🎨 現代毛玻璃中控台：專屬懸浮球設計，所有功能開關皆可隨心切換。

【如何使用】
1. 安裝 GhostGram 擴充功能。
2. 開啟或重新整理 Instagram 網頁版 (instagram.com)。
3. 頁面右下角即會出現 👻 懸浮按鈕，點擊即可開啟中控面板自訂功能！

【隱私與安全承諾】
GhostGram 尊重每位使用者的數據隱私。本擴充功能所有過濾與隱私攔截皆在您的本機瀏覽器內端對端執行，絕不收集、追蹤或傳輸您的任何帳號、密碼或個人隱私資料至外部伺服器。

【支援與意見反饋】
如有任何問題、功能建議或反饋，歡迎造訪開發者網站或透過聯繫管道取得支援。

**Category** [REQUIRED]
Social & Communication (社群與通訊) 或 Productivity (實用工具)

**Single Purpose** [REQUIRED]
Enhance privacy and user experience on Instagram Web by enabling anonymous story/DM viewing, blocking ads, and downloading media.
(在 Instagram 網頁版上提供限動與私訊無痕隱私防護、過濾廣告及媒體下載增強體驗。)

**Primary Language** [REQUIRED]
中文 (繁體) / Chinese (Traditional) 或 英文 (English)

---

## Graphics & Assets

| Asset | Dimensions | Status | Filename |
|-------|-----------|--------|----------|
| Store Icon [REQUIRED] | 128×128 PNG | ✅ Ready | `icons/icon-128.png` |
| Screenshot 1 [REQUIRED] | 1280×800 or 640×400 | ⬜ Not created | `store-assets/screenshot-1.png` (動態牆隱身中控面板與下載按鈕) |
| Screenshot 2 [RECOMMENDED] | 1280×800 or 640×400 | ⬜ Not created | `store-assets/screenshot-2.png` (無痕限動與私訊防已讀展示) |
| Screenshot 3 [RECOMMENDED] | 1280×800 or 640×400 | ⬜ Not created | `store-assets/screenshot-3.png` (廣告過濾與靜音功能) |
| Small Promo Tile [RECOMMENDED] | 440×280 PNG | ⬜ Not created | `store-assets/promo-small.png` |
| Marquee Promo Tile | 1400×560 PNG | ⬜ Not created | `store-assets/promo-marquee.png` |

---

## Permissions Justification

| Permission | Type | Justification (審查填寫原因 - 勿刪改) |
|------------|------|------------------------------------|
| declarativeNetRequest | permissions | Used to block Instagram seen receipt network beacons and tracking requests at the network level, ensuring anonymous browsing without sending read notifications. |
| storage | permissions | Used to save user preferences locally (such as toggle states for stealth modes, ad blocking, default mute, and language selection). |
| scripting | permissions | Used to synchronize live toggle state and counters between the extension popup and active Instagram tabs. |
| activeTab | permissions | Used to safely interact with the current Instagram tab when the user clicks the extension action icon. |
| `*://*.instagram.com/*` | content_scripts | Required to display the floating in-page control center, filter sponsored ad elements from the feed DOM, and provide the one-click media download button on instagram.com. |

---

## Privacy & Data Use

### Data Collection
**Does the extension collect user data?** No

All operations, intercept logic, and media download helpers execute completely locally within the user's browser. No personal information, user communications, or browsing histories are collected, stored externally, or transmitted off the device.

### Data Use Certification
- [x] Data is NOT sold to third parties
- [x] Data is NOT used for purposes unrelated to the extension's core functionality
- [x] Data is NOT used for creditworthiness or lending purposes

---

## Privacy Policy

**Privacy Policy URL** [REQUIRED]
`https://kkleon.com/privacy/ghostgram`

---

## Distribution

**Visibility**: Public
**Regions**: All regions

## Developer Info

**Publisher Name** [REQUIRED]
Kai Liu

**Contact Email** [REQUIRED]
（填寫您的 Google 帳號開發者信箱）

**Homepage URL** [RECOMMENDED]
`https://kkleon.com`

---

## Version History

| Version | Date | Changes | Status |
|---------|------|---------|--------|
| 1.3.0 | 2026-10-12 | 新增廣告過濾、預設靜音、高清原檔下載、中英雙語面板與獨立隱身開關 | Ready for Submission |

