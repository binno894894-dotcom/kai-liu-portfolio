/**
 * GhostGram Chrome Extension - Content Script (MAIN World)
 * Injected automatically into instagram.com at document_start
 *
 * Full-Coverage Interception:
 * 1. GraphQL Mutations (PolarisStoriesV3SeenMutation, useIGDMarkThreadAsReadMutation, etc.)
 * 2. REST Endpoints (/stories/reel/seen, /direct_v2/threads/.../seen)
 * 3. SharedWorker Fallback Enforcement (forces background worker to main-thread fetch)
 * 4. Navigator sendBeacon API Interception
 * 5. MQTT WebSockets (typing_activity frame dropping)
 */

(function () {
  if (window.__GHOSTGRAM_EXT_ACTIVE__) return;
  window.__GHOSTGRAM_EXT_ACTIVE__ = true;

  console.log("%c[GhostGram 👻] 隱身模式已成功注入 Instagram！(v1.1.0 GraphQL/REST 雙層防護啟動)", "color: #FF2D55; font-weight: bold; font-size: 13px;");

  // Force SharedWorker fallback to window.fetch on instagram.com
  // Instagram falls back cleanly to main-thread fetch when SharedWorker is disabled.
  try {
    Object.defineProperty(window, "SharedWorker", {
      get: function () { return undefined; },
      set: function () {},
      configurable: false
    });
  } catch (_) {
    try { delete window.SharedWorker; } catch (_) {}
  }

  // Load config from localStorage
  const defaultConfig = {
    ghostMode: true,
    showToasts: true,
    showFab: true,
    storyBlocked: 0,
    dmBlocked: 0
  };

  let savedConfig = {};
  try {
    const raw = localStorage.getItem("ghostgram_config");
    if (raw) savedConfig = JSON.parse(raw);
  } catch (_) {}

  window.__GHOSTGRAM_CONFIG__ = { ...defaultConfig, ...savedConfig };

  function saveConfig() {
    try {
      localStorage.setItem("ghostgram_config", JSON.stringify(window.__GHOSTGRAM_CONFIG__));
    } catch (_) {}
  }

  // Record Block and update UI
  function recordBlock(type, label) {
    if (type === "story") {
      window.__GHOSTGRAM_CONFIG__.storyBlocked = (window.__GHOSTGRAM_CONFIG__.storyBlocked || 0) + 1;
    } else {
      window.__GHOSTGRAM_CONFIG__.dmBlocked = (window.__GHOSTGRAM_CONFIG__.dmBlocked || 0) + 1;
    }
    saveConfig();
    updateBadge();

    const icon = type === "story" ? "👁️" : "💬";
    showToast(`GhostGram: 已成功攔截 ${label}`, icon);
    console.log(`%c[GhostGram 👻] 攔截成功 [${type.toUpperCase()}]: ${label}`, "color: #10B981; font-weight: bold;");
  }

  // 1. Toast Notification System
  function showToast(message, icon = "👻") {
    if (!window.__GHOSTGRAM_CONFIG__.showToasts) return;
    const existing = document.getElementById("ghostgram-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.id = "ghostgram-toast";
    toast.style.cssText = `
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(18, 18, 24, 0.95);
      color: #ffffff;
      border: 1px solid rgba(255, 45, 85, 0.6);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6), 0 0 20px rgba(255, 45, 85, 0.35);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-radius: 9999px;
      padding: 10px 22px;
      font-size: 13px;
      font-weight: 500;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 10px;
      pointer-events: none;
      transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      opacity: 0;
      transform: translate(-50%, -10px) scale(0.95);
    `;
    toast.innerHTML = `<span style="font-size:16px;">${icon}</span><span style="letter-spacing:0.3px;">${message}</span>`;
    if (document.body) {
      document.body.appendChild(toast);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        if (document.body) document.body.appendChild(toast);
      });
    }

    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translate(-50%, 0) scale(1)";
    });

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translate(-50%, -10px) scale(0.95)";
      setTimeout(() => toast.remove(), 350);
    }, 2800);
  }

  // 2. Request Parsing & Inspector Logic
  function inspectRequest(input, init) {
    let url = "";
    let method = "GET";
    let headers = null;
    let body = null;

    if (typeof input === "string") {
      url = input;
    } else if (input && typeof input === "object") {
      if (input.url) url = input.url;
      if (input.method) method = input.method;
      if (input.headers) headers = input.headers;
    }

    if (init) {
      if (init.method) method = init.method;
      if (init.headers) headers = init.headers;
      if (init.body) body = init.body;
    }

    // Extract X-FB-Friendly-Name
    let friendlyName = "";
    if (headers) {
      try {
        if (typeof headers.get === "function") {
          friendlyName = headers.get("X-FB-Friendly-Name") || headers.get("x-fb-friendly-name") || "";
        } else if (typeof headers === "object") {
          friendlyName = headers["X-FB-Friendly-Name"] || headers["x-fb-friendly-name"] || "";
        }
      } catch (_) {}
    }

    // Extract body content
    let bodyText = "";
    try {
      if (typeof body === "string") {
        bodyText = body;
      } else if (body instanceof URLSearchParams) {
        bodyText = body.toString();
        if (!friendlyName) friendlyName = body.get("fb_api_req_friendly_name") || "";
      } else if (body && typeof body.get === "function") { // FormData
        if (!friendlyName) friendlyName = body.get("fb_api_req_friendly_name") || "";
        try {
          for (let [k, v] of body.entries()) {
            if (typeof v === "string") bodyText += k + "=" + v + "&";
          }
        } catch (_) {}
      } else if (body && typeof body === "object") {
        bodyText = JSON.stringify(body);
      }
    } catch (_) {}

    return { url, method, friendlyName, bodyText };
  }

  function shouldBlockSeen(info) {
    const { url, friendlyName, bodyText } = info;
    const urlLower = (url || "").toLowerCase();
    const fn = (friendlyName || "").toLowerCase();
    const b = (bodyText || "").toLowerCase();

    // 1. Stories Seen Check
    const isStorySeen =
      // GraphQL mutation names
      fn.includes("polarisstoriesv3seenmutation") ||
      fn.includes("polarisapireelseenmutation") ||
      fn.includes("polarisstoriesseenmutation") ||
      fn.includes("storiesseenmutation") ||
      // Body content matches
      b.includes("polarisstoriesv3seenmutation") ||
      b.includes("polarisapireelseenmutation") ||
      b.includes("polarisstoriesseenmutation") ||
      b.includes("stories_seen") ||
      // REST URL matches
      urlLower.includes("/stories/reel/seen") ||
      urlLower.includes("stories_seen") ||
      urlLower.includes("/api/v1/stories/reel/seen");

    if (isStorySeen) {
      return { block: true, type: "story", label: friendlyName || "限時動態已讀" };
    }

    // 2. DM Read / Seen Check
    const isDmSeen =
      // GraphQL mutation names
      fn.includes("useigdmarkthreadasreadmutation") ||
      fn.includes("useigdmarkthreadasreadvalidationmutation") ||
      fn.includes("useigdmarkthreadasseenmutation") ||
      fn.includes("polarisdirectmarkasseenmutation") ||
      fn.includes("directmarkasseenmutation") ||
      fn.includes("markthreadasread") ||
      // Body content matches
      b.includes("useigdmarkthreadasreadmutation") ||
      b.includes("useigdmarkthreadasreadvalidationmutation") ||
      b.includes("useigdmarkthreadasseenmutation") ||
      b.includes("polarisdirectmarkasseenmutation") ||
      b.includes("markthreadasread") ||
      b.includes("mark_thread_read") ||
      // REST URL matches
      urlLower.includes("/direct_v2/threads/") && (urlLower.includes("/seen") || urlLower.includes("mark_as_seen")) ||
      urlLower.includes("mark_as_seen") ||
      urlLower.includes("mark_thread_read");

    if (isDmSeen) {
      return { block: true, type: "dm", label: friendlyName || "私訊已讀" };
    }

    return { block: false };
  }

  // 3. Network Interceptors (fetch, XMLHttpRequest, sendBeacon, WebSocket)
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    if (window.__GHOSTGRAM_CONFIG__.ghostMode) {
      const info = inspectRequest(args[0], args[1]);
      const check = shouldBlockSeen(info);
      if (check.block) {
        recordBlock(check.type, check.label);
        return new Response(JSON.stringify({ data: {}, status: "ok" }), {
          status: 200,
          headers: { "Content-Type": "application/json" }
        });
      }
    }
    return origFetch.apply(this, args);
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__gg_url = url;
    this.__gg_method = method;
    this.__gg_headers = {};
    return origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (header, value) {
    if (!this.__gg_headers) this.__gg_headers = {};
    this.__gg_headers[header] = value;
    return origSetHeader.apply(this, [header, value]);
  };

  XMLHttpRequest.prototype.send = function (body) {
    if (window.__GHOSTGRAM_CONFIG__.ghostMode) {
      const info = inspectRequest(this.__gg_url, {
        method: this.__gg_method,
        headers: this.__gg_headers,
        body: body
      });
      const check = shouldBlockSeen(info);
      if (check.block) {
        recordBlock(check.type, check.label);

        Object.defineProperty(this, "status", { value: 200, writable: true, configurable: true });
        Object.defineProperty(this, "statusText", { value: "OK", writable: true, configurable: true });
        Object.defineProperty(this, "responseText", { value: JSON.stringify({ data: {}, status: "ok" }), writable: true, configurable: true });
        Object.defineProperty(this, "response", { value: JSON.stringify({ data: {}, status: "ok" }), writable: true, configurable: true });
        Object.defineProperty(this, "readyState", { value: 4, writable: true, configurable: true });

        setTimeout(() => {
          if (typeof this.onreadystatechange === "function") this.onreadystatechange(new Event("readystatechange"));
          if (typeof this.onload === "function") this.onload(new Event("load"));
          if (typeof this.onloadend === "function") this.onloadend(new Event("loadend"));
          this.dispatchEvent(new Event("readystatechange"));
          this.dispatchEvent(new Event("load"));
          this.dispatchEvent(new Event("loadend"));
        }, 0);
        return;
      }
    }
    return origSend.apply(this, [body]);
  };

  // Intercept navigator.sendBeacon
  if (navigator && navigator.sendBeacon) {
    const origSendBeacon = navigator.sendBeacon;
    navigator.sendBeacon = function (url, data) {
      if (window.__GHOSTGRAM_CONFIG__.ghostMode) {
        const info = inspectRequest(url, { body: data });
        const check = shouldBlockSeen(info);
        if (check.block) {
          recordBlock(check.type, check.label);
          return true;
        }
      }
      return origSendBeacon.apply(this, arguments);
    };
  }

  // Intercept WebSocket frames (MQTT real-time activity)
  if (window.WebSocket) {
    const origWsSend = WebSocket.prototype.send;
    WebSocket.prototype.send = function (data) {
      if (window.__GHOSTGRAM_CONFIG__.ghostMode) {
        try {
          let text = "";
          if (typeof data === "string") {
            text = data;
          } else if (data instanceof ArrayBuffer) {
            text = new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(data));
          } else if (ArrayBuffer.isView(data)) {
            text = new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
          }
          if (text) {
            if (text.includes("typing_activity") || text.includes("useIGDMarkThreadAsRead") || text.includes("mark_seen")) {
              recordBlock("dm", "實時輸入/已讀狀態信號 (MQTT)");
              return;
            }
          }
        } catch (_) {}
      }
      return origWsSend.apply(this, arguments);
    };
  }

  // 4. UI Construction (Floating Button & Control Panel)
  function initUI() {
    if (document.getElementById("ghostgram-fab")) return;

    const btn = document.createElement("div");
    btn.id = "ghostgram-fab";
    btn.style.cssText = `
      position: fixed;
      bottom: 40px;
      right: 40px;
      width: 54px;
      height: 54px;
      border-radius: 50%;
      background: linear-gradient(135deg, #FF2D55 0%, #E1306C 50%, #F77737 100%);
      box-shadow: 0 8px 24px rgba(225, 48, 108, 0.45), 0 2px 8px rgba(0,0,0,0.25);
      cursor: pointer;
      z-index: 2147483646;
      display: ${window.__GHOSTGRAM_CONFIG__.showFab ? "flex" : "none"};
      align-items: center;
      justify-content: center;
      user-select: none;
      touch-action: none;
      transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease;
    `;
    btn.innerHTML = `
      <svg style="width:28px;height:28px;fill:white;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.2));" viewBox="0 0 24 24">
        <path d="M12 2C7.58 2 4 5.58 4 10v9.5c0 .69.69 1.15 1.31.84L7.5 19.3l2.19 1.04c.4.19.88.19 1.28 0l2.03-.97 2.03.97c.4.19.88.19 1.28 0l2.19-1.04 2.19 1.04c.62.31 1.31-.15 1.31-.84V10c0-4.42-3.58-8-8-8zm-2.5 10c-.83 0-1.5-.67-1.5-1.5S8.67 9 9.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm5 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
      </svg>
      <div id="ghostgram-badge" style="position:absolute;top:-4px;right:-4px;background:#10B981;color:white;font-size:10px;font-weight:700;padding:2px 6px;border-radius:10px;border:2px solid #fff;display:none;box-shadow:0 2px 6px rgba(0,0,0,0.2);">0</div>
    `;

    const panel = document.createElement("div");
    panel.id = "ghostgram-panel";
    panel.style.cssText = `
      position: fixed;
      bottom: 105px;
      right: 40px;
      width: 320px;
      background: rgba(22, 22, 28, 0.95);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 24px;
      padding: 20px;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.7), 0 0 30px rgba(225, 48, 108, 0.15);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 2147483646;
      display: none;
    `;

    function renderPanel() {
      const isGhost = window.__GHOSTGRAM_CONFIG__.ghostMode;
      const isToast = window.__GHOSTGRAM_CONFIG__.showToasts;
      panel.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="width:10px;height:10px;border-radius:50%;background:${isGhost ? '#10B981' : '#EF4444'};box-shadow:0 0 8px ${isGhost ? '#10B981' : '#EF4444'};"></div>
            <span style="font-weight:700;font-size:15px;letter-spacing:0.3px;">GhostGram 隱身中控</span>
          </div>
          <button id="gg-close-btn" style="background:none;border:none;color:#888;cursor:pointer;font-size:16px;padding:4px;margin-left:auto;">✕</button>
        </div>

        <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.05);border-radius:14px;">
            <div>
              <div style="font-size:13px;font-weight:600;">👻 隱身模式</div>
              <div style="font-size:11px;color:#aaa;">攔截限動與私訊已讀打點</div>
            </div>
            <label style="position:relative;display:inline-block;width:44px;height:24px;cursor:pointer;">
              <input type="checkbox" id="gg-ghost-toggle" ${isGhost ? 'checked' : ''} style="opacity:0;width:0;height:0;">
              <span style="position:absolute;inset:0;background:${isGhost ? '#FF2D55' : '#444'};border-radius:24px;transition:0.2s;">
                <span style="position:absolute;height:18px;width:18px;left:${isGhost ? '22px' : '3px'};bottom:3px;background:white;border-radius:50%;transition:0.2s;"></span>
              </span>
            </label>
          </div>

          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.05);border-radius:14px;">
            <div>
              <div style="font-size:13px;font-weight:600;">🔔 攔截浮動提示</div>
              <div style="font-size:11px;color:#aaa;">攔截成功時顯示通知</div>
            </div>
            <label style="position:relative;display:inline-block;width:44px;height:24px;cursor:pointer;">
              <input type="checkbox" id="gg-toast-toggle" ${isToast ? 'checked' : ''} style="opacity:0;width:0;height:0;">
              <span style="position:absolute;inset:0;background:${isToast ? '#FF2D55' : '#444'};border-radius:24px;transition:0.2s;">
                <span style="position:absolute;height:18px;width:18px;left:${isToast ? '22px' : '3px'};bottom:3px;background:white;border-radius:50%;transition:0.2s;"></span>
              </span>
            </label>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;">
          <div style="background:rgba(255,255,255,0.04);border-radius:12px;padding:10px;text-align:center;">
            <div style="font-size:11px;color:#888;">已攔截限動</div>
            <div style="font-size:18px;font-weight:700;color:#FF2D55;" id="gg-stat-story">${window.__GHOSTGRAM_CONFIG__.storyBlocked || 0} 次</div>
          </div>
          <div style="background:rgba(255,255,255,0.04);border-radius:12px;padding:10px;text-align:center;">
            <div style="font-size:11px;color:#888;">已攔截私訊</div>
            <div style="font-size:18px;font-weight:700;color:#F77737;" id="gg-stat-dm">${window.__GHOSTGRAM_CONFIG__.dmBlocked || 0} 次</div>
          </div>
        </div>

        <div style="text-align:center;font-size:11px;color:#666;">
          GhostGram v1.1 • 由 <a href="https://kkleon.com" target="_blank" style="color:#FF2D55;text-decoration:none;">Kai Liu</a> 開發
        </div>
      `;

      document.getElementById("gg-close-btn").onclick = () => { panel.style.display = "none"; };
      document.getElementById("gg-ghost-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.ghostMode = e.target.checked;
        saveConfig();
        renderPanel();
        showToast(window.__GHOSTGRAM_CONFIG__.ghostMode ? "隱身模式已啟用" : "隱身模式已停用", window.__GHOSTGRAM_CONFIG__.ghostMode ? "👻" : "⚠️");
      };
      document.getElementById("gg-toast-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.showToasts = e.target.checked;
        saveConfig();
        renderPanel();
      };
    }

    // Draggable logic
    let isDragging = false;
    let startX, startY, initialX, initialY;

    btn.addEventListener("mousedown", (e) => {
      isDragging = false;
      startX = e.clientX;
      startY = e.clientY;
      const rect = btn.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;

      function onMouseMove(moveEvent) {
        const dx = moveEvent.clientX - startX;
        const dy = moveEvent.clientY - startY;
        if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
          isDragging = true;
          btn.style.right = "auto";
          btn.style.bottom = "auto";
          btn.style.left = `${initialX + dx}px`;
          btn.style.top = `${initialY + dy}px`;
        }
      }

      function onMouseUp() {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      }

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    });

    btn.addEventListener("click", () => {
      if (!isDragging) {
        if (panel.style.display === "none" || panel.style.display === "") {
          renderPanel();
          panel.style.display = "block";
          const rect = btn.getBoundingClientRect();
          panel.style.bottom = "auto";
          panel.style.right = "auto";
          let top = rect.top - 290;
          let left = rect.left - 130;
          if (top < 10) top = rect.bottom + 10;
          if (left < 10) left = 10;
          if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
          panel.style.top = `${top}px`;
          panel.style.left = `${left}px`;
        } else {
          panel.style.display = "none";
        }
      }
    });

    if (document.body) {
      document.body.appendChild(btn);
      document.body.appendChild(panel);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        if (document.body) {
          document.body.appendChild(btn);
          document.body.appendChild(panel);
        }
      });
    }

    updateBadge();
  }

  function updateBadge() {
    const total = (window.__GHOSTGRAM_CONFIG__.storyBlocked || 0) + (window.__GHOSTGRAM_CONFIG__.dmBlocked || 0);
    const badge = document.getElementById("ghostgram-badge");
    if (badge) {
      badge.textContent = total;
      badge.style.display = total > 0 ? "block" : "none";
    }
    const statStory = document.getElementById("gg-stat-story");
    const statDm = document.getElementById("gg-stat-dm");
    if (statStory) statStory.textContent = `${window.__GHOSTGRAM_CONFIG__.storyBlocked || 0} 次`;
    if (statDm) statDm.textContent = `${window.__GHOSTGRAM_CONFIG__.dmBlocked || 0} 次`;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initUI);
  } else {
    initUI();
  }
})();
