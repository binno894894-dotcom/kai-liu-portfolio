/**
 * GhostGram Chrome Extension - Content Script (MAIN World)
 * Injected automatically into instagram.com at document_start
 *
 * Full Capabilities (Synchronized with GhostGram App):
 * 1. 🟣 隱身看限動 (Ghost Stories): GraphQL & REST seen mutations interception
 * 2. 🔵 防訊息已讀 (Ghost DM): Direct message read receipts & MQTT typing frames blocking
 * 3. 🟢 去除贊助廣告與推薦 (AdBlock): Automatically hide sponsored posts & algorithm suggestions
 * 4. 🔇 影片與限動預設靜音 (Default Audio Mute): Auto-mute on load to prevent audio blasts
 * 5. 📥 高清圖片/影片/限動快捷下載 (HD Media Downloader): One-click download button on posts & story player
 * 6. 🔔 攔截浮動通知 (Toast Notifications)
 * 7. 🌐 多語言切換支援 (I18n: 繁體中文 & English)
 */

(function () {
  if (window.__GHOSTGRAM_EXT_ACTIVE__) return;
  window.__GHOSTGRAM_EXT_ACTIVE__ = true;

  console.log("%c[GhostGram 👻] 隱身模式與增強套件已啟動 (v1.3.0 電腦網頁版全功能就緒)", "color: #FF2D55; font-weight: bold; font-size: 13px;");

  // 1. Force SharedWorker fallback to window.fetch on instagram.com
  try {
    Object.defineProperty(window, "SharedWorker", {
      get: function () { return undefined; },
      set: function () {},
      configurable: false
    });
  } catch (_) {
    try { delete window.SharedWorker; } catch (_) {}
  }

  // 2. I18n Multi-language Dictionary
  const I18N = {
    zh: {
      title: "GhostGram 隱身中控",
      status_active: "防護中 (GraphQL / REST 雙層攔截)",
      status_inactive: "防護已暫停",
      sec_stealth: "隱身與防已讀",
      sec_enhanced: "瀏覽增強功能",
      sec_prefs: "系統與偏好",
      ghost_stories: "🟣 隱身看限動 (Stories)",
      ghost_stories_sub: "觀看限時動態不留下已看紀錄",
      ghost_dm: "🔵 防訊息已讀 (DM)",
      ghost_dm_sub: "打開私訊聊天室維持未讀狀態",
      block_ads: "🟢 去除贊助廣告與推薦 (AdBlock)",
      block_ads_sub: "自動隱藏贊助貼文與演算法推薦追蹤",
      default_mute: "🔇 影片與限動預設靜音",
      default_mute_sub: "載入影音時自動靜音，防公共場合突發爆音",
      downloader: "📥 高清圖片/影片快捷下載",
      downloader_sub: "滑鼠懸停圖片或影片即可一鍵儲存原檔",
      toasts: "🔔 顯示攔截浮動提示",
      toasts_sub: "攔截已讀請求時顯示通知膠囊",
      stat_story: "已攔截限動",
      stat_dm: "已攔截私訊",
      stat_ads: "已過濾廣告",
      times_unit: "次",
      download_btn_tip: "📥 下載高清原檔",
      story_download_btn: "📥 下載本則限動",
      downloading: "⏳ 正在獲取高清原檔...",
      download_success: "✅ 儲存成功！已下載高清原檔",
      download_failed: "❌ 下載失敗，已嘗試直接開啟直鏈",
      toast_story_blocked: "GhostGram: 已成功攔截限動已讀",
      toast_dm_blocked: "GhostGram: 已成功攔截私訊已讀",
      toast_ad_blocked: "GhostGram: 已過濾贊助廣告",
      lang_name: "語言 / Language",
      just_now: "剛剛"
    },
    en: {
      title: "GhostGram Control Center",
      status_active: "Active Protection (Dual-Layer Interception)",
      status_inactive: "Protection Paused",
      sec_stealth: "Stealth & Privacy",
      sec_enhanced: "Enhanced Browsing",
      sec_prefs: "System & Preferences",
      ghost_stories: "🟣 Ghost Mode for Stories",
      ghost_stories_sub: "View stories anonymously without seen receipts",
      ghost_dm: "🔵 Unseen Direct Messages (DM)",
      ghost_dm_sub: "Read chats while keeping messages marked as unread",
      block_ads: "🟢 Block Sponsored Ads & Suggestions",
      block_ads_sub: "Automatically hide sponsored ads & suggested posts",
      default_mute: "🔇 Mute Audio by Default",
      default_mute_sub: "Mute reels & stories on load to prevent sudden blasts",
      downloader: "📥 HD Media Quick Downloader",
      downloader_sub: "Hover over post images or videos to save original media",
      toasts: "🔔 Show Block Notifications",
      toasts_sub: "Display toast notifications when an event is blocked",
      stat_story: "Stories Blocked",
      stat_dm: "DMs Blocked",
      stat_ads: "Ads Filtered",
      times_unit: "times",
      download_btn_tip: "📥 Download HD Media",
      story_download_btn: "📥 Download This Story",
      downloading: "⏳ Fetching HD media file...",
      download_success: "✅ Saved successfully! Downloaded HD original",
      download_failed: "❌ Download failed, opening direct link",
      toast_story_blocked: "GhostGram: Blocked story seen receipt",
      toast_dm_blocked: "GhostGram: Blocked DM read receipt",
      toast_ad_blocked: "GhostGram: Sponsored ad filtered",
      lang_name: "Language / 語言",
      just_now: "just now"
    }
  };

  // 3. Load & Initialize Config
  const defaultConfig = {
    ghostStories: true,
    ghostDm: true,
    blockAds: true,
    defaultMute: true,
    enableDownloader: true,
    showToasts: true,
    showFab: true,
    language: "zh",
    storyBlocked: 0,
    dmBlocked: 0,
    adsBlocked: 0
  };

  let savedConfig = {};
  try {
    const raw = localStorage.getItem("ghostgram_config");
    if (raw) savedConfig = JSON.parse(raw);
  } catch (_) {}

  window.__GHOSTGRAM_CONFIG__ = { ...defaultConfig, ...savedConfig };

  function t(key) {
    const lang = window.__GHOSTGRAM_CONFIG__.language === "en" ? "en" : "zh";
    return I18N[lang][key] || I18N.zh[key] || key;
  }

  function isZh() {
    return window.__GHOSTGRAM_CONFIG__.language !== "en";
  }

  function saveConfig() {
    try {
      localStorage.setItem("ghostgram_config", JSON.stringify(window.__GHOSTGRAM_CONFIG__));
    } catch (_) {}
  }

  // 4. Toast Notification System
  function showToast(message, icon = "👻") {
    if (!window.__GHOSTGRAM_CONFIG__.showToasts) return;
    const existing = document.getElementById("ghostgram-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.id = "ghostgram-toast";
    toast.style.cssText = `
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(18, 18, 24, 0.95);
      color: #ffffff;
      border: 1px solid rgba(255, 45, 85, 0.6);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6), 0 0 20px rgba(255, 45, 85, 0.35);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-radius: 9999px;
      padding: 10px 22px;
      font-size: 13px;
      font-weight: 500;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 10px;
      pointer-events: none;
      transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      opacity: 0;
      transform: translate(-50%, -10px) scale(0.95);
    `;
    toast.innerHTML = `<span style="font-size:16px;">${icon}</span><span style="letter-spacing:0.3px;">${message}</span>`;
    if (document.body) {
      document.body.appendChild(toast);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        if (document.body) document.body.appendChild(toast);
      });
    }

    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translate(-50%, 0) scale(1)";
    });

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translate(-50%, -10px) scale(0.95)";
      setTimeout(() => toast.remove(), 350);
    }, 2800);
  }

  // 5. Block Recorder
  function recordBlock(type, label) {
    if (type === "story") {
      window.__GHOSTGRAM_CONFIG__.storyBlocked = (window.__GHOSTGRAM_CONFIG__.storyBlocked || 0) + 1;
      showToast(t("toast_story_blocked"), "👁️");
    } else if (type === "dm") {
      window.__GHOSTGRAM_CONFIG__.dmBlocked = (window.__GHOSTGRAM_CONFIG__.dmBlocked || 0) + 1;
      showToast(t("toast_dm_blocked"), "💬");
    } else if (type === "ad") {
      window.__GHOSTGRAM_CONFIG__.adsBlocked = (window.__GHOSTGRAM_CONFIG__.adsBlocked || 0) + 1;
      showToast(t("toast_ad_blocked"), "🛡️");
    }
    saveConfig();
    updateBadge();
    console.log(`%c[GhostGram 👻] 攔截成功 [${type.toUpperCase()}]: ${label}`, "color: #10B981; font-weight: bold;");
  }

  // 6. Network Request Inspection Logic
  function inspectRequest(input, init) {
    let url = "";
    let method = "GET";
    let headers = null;
    let body = null;

    if (typeof input === "string") {
      url = input;
    } else if (input && typeof input === "object") {
      if (input.url) url = input.url;
      if (input.method) method = input.method;
      if (input.headers) headers = input.headers;
    }

    if (init) {
      if (init.method) method = init.method;
      if (init.headers) headers = init.headers;
      if (init.body) body = init.body;
    }

    let friendlyName = "";
    if (headers) {
      try {
        if (typeof headers.get === "function") {
          friendlyName = headers.get("X-FB-Friendly-Name") || headers.get("x-fb-friendly-name") || "";
        } else if (typeof headers === "object") {
          friendlyName = headers["X-FB-Friendly-Name"] || headers["x-fb-friendly-name"] || "";
        }
      } catch (_) {}
    }

    let bodyText = "";
    try {
      if (typeof body === "string") {
        bodyText = body;
      } else if (body instanceof URLSearchParams) {
        bodyText = body.toString();
        if (!friendlyName) friendlyName = body.get("fb_api_req_friendly_name") || "";
      } else if (body && typeof body.get === "function") {
        if (!friendlyName) friendlyName = body.get("fb_api_req_friendly_name") || "";
        try {
          for (let [k, v] of body.entries()) {
            if (typeof v === "string") bodyText += k + "=" + v + "&";
          }
        } catch (_) {}
      } else if (body && typeof body === "object") {
        bodyText = JSON.stringify(body);
      }
    } catch (_) {}

    return { url, method, friendlyName, bodyText };
  }

  function shouldBlockSeen(info) {
    const { url, friendlyName, bodyText } = info;
    const urlLower = (url || "").toLowerCase();
    const fn = (friendlyName || "").toLowerCase();
    const b = (bodyText || "").toLowerCase();

    // 0. ABSOLUTE EXCEPTION: Never block viewer list queries or reel viewer queries!
    if (
      fn.includes("viewer") ||
      fn.includes("storyviewer") ||
      fn.includes("polarisstoriesv3viewerlistquery") ||
      urlLower.includes("viewer") ||
      urlLower.includes("list_reel_media_viewer") ||
      b.includes("polarisstoriesv3viewerlistquery") ||
      b.includes("list_reel_media_viewer") ||
      b.includes("xdt_api__v1__media__list_reel_media_viewer")
    ) {
      return { block: false };
    }

    // 1. Stories Seen Check (Respect ghostStories toggle)
    if (window.__GHOSTGRAM_CONFIG__.ghostStories) {
      const isStorySeen =
        fn.includes("polarisstoriesv3seenmutation") ||
        fn.includes("polarisapireelseenmutation") ||
        fn.includes("polarisstoriesseenmutation") ||
        fn.includes("storiesseenmutation") ||
        fn === "stories_seen" ||
        urlLower.includes("/stories/reel/seen") ||
        urlLower.includes("/api/v1/stories/reel/seen") ||
        urlLower.includes("/api/v1/media/seen") ||
        b.includes("polarisstoriesv3seenmutation") ||
        b.includes("polarisapireelseenmutation") ||
        b.includes("polarisstoriesseenmutation");

      if (isStorySeen) {
        return { block: true, type: "story", label: friendlyName || "限時動態已讀" };
      }
    }

    // 2. DM Read / Seen Check (Respect ghostDm toggle)
    if (window.__GHOSTGRAM_CONFIG__.ghostDm) {
      const isDmSeen =
        fn.includes("useigdmarkthreadasreadmutation") ||
        fn.includes("useigdmarkthreadasreadvalidationmutation") ||
        fn.includes("useigdmarkthreadasseenmutation") ||
        fn.includes("polarisdirectmarkasseenmutation") ||
        fn.includes("polarisdirectthreadmarkseen") ||
        fn.includes("directmarkasseenmutation") ||
        fn.includes("markthreadasread") ||
        b.includes("useigdmarkthreadasreadmutation") ||
        b.includes("useigdmarkthreadasreadvalidationmutation") ||
        b.includes("useigdmarkthreadasseenmutation") ||
        b.includes("polarisdirectmarkasseenmutation") ||
        b.includes("polarisdirectthreadmarkseen") ||
        b.includes("markthreadasread") ||
        b.includes("mark_thread_read") ||
        b.includes("direct_thread_mark_seen") ||
        urlLower.includes("/direct_v2/threads/") && (urlLower.includes("/seen") || urlLower.includes("mark_as_seen")) ||
        urlLower.includes("mark_as_seen") ||
        urlLower.includes("mark_thread_read") ||
        urlLower.includes("direct_thread_mark_seen");

      if (isDmSeen) {
        return { block: true, type: "dm", label: friendlyName || "私訊已讀" };
      }
    }

    return { block: false };
  }

  // 8. 🟢 去除贊助廣告與推薦系統 (AdBlock)
  function cleanAdsAndSuggestions() {
    if (!window.__GHOSTGRAM_CONFIG__.blockAds) return;
    try {
      const articles = document.querySelectorAll('article:not([data-ghost-checked])');
      for (let i = 0; i < articles.length; i++) {
        const art = articles[i];
        art.setAttribute('data-ghost-checked', '1');
        const text = art.innerText || '';
        const isSponsored =
          text.includes('Sponsored') ||
          text.includes('贊助') ||
          text.includes('赞助') ||
          art.querySelector('a[href*="/about/ads/"]') ||
          art.querySelector('a[href*="/ads/"]');

        if (isSponsored) {
          art.style.display = 'none';
          art.setAttribute('data-ghost-ad', '1');
          window.__GHOSTGRAM_CONFIG__.adsBlocked = (window.__GHOSTGRAM_CONFIG__.adsBlocked || 0) + 1;
          saveConfig();
          updateBadge();
          console.log('%c[GhostGram 🟢] 已自動去除贊助貼文！', 'color: #10B981;');
        }
      }
    } catch (_) {}
  }

  // 9. 🔇 影片與限動預設靜音系統 (Default Audio Mute)
  function applyDefaultMute() {
    if (!window.__GHOSTGRAM_CONFIG__.defaultMute) return;
    try {
      const vids = document.querySelectorAll('video');
      for (let i = 0; i < vids.length; i++) {
        const v = vids[i];
        if (!v.dataset.ghostMuted) {
          v.dataset.ghostMuted = '1';
          v.muted = true;
          v.setAttribute('muted', '');
        }
      }
    } catch (_) {}
  }

  // 10. 📥 高清圖片/影片快捷下載系統 (HD Media Downloader)
  window.__lastFetchedVideoUrl = "";

  function getBestImageUrl(img) {
    if (!img) return "";
    if (img.srcset) {
      const candidates = img.srcset.split(",").map(part => {
        const [url, width] = part.trim().split(" ");
        return { url, width: width ? parseInt(width, 10) : 0 };
      });
      candidates.sort((a, b) => b.width - a.width);
      if (candidates.length > 0 && candidates[0].url) {
        return candidates[0].url;
      }
    }
    return img.currentSrc || img.src || "";
  }

  function getBestVideoUrl(video) {
    if (!video) return window.__lastFetchedVideoUrl || "";
    let src = video.currentSrc || video.src || "";
    if (!src || src.startsWith("blob:")) {
      const sources = video.querySelectorAll("source");
      for (let s of sources) {
        if (s.src && s.src.startsWith("http")) {
          return s.src;
        }
      }
    }
    return src || window.__lastFetchedVideoUrl || "";
  }

  async function downloadMedia(url, isVideo = false) {
    if (!url) return;
    showToast(t("downloading"), "📥");
    try {
      const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
      const ext = isVideo ? "mp4" : "jpg";
      const filename = `GhostGram_instagram_${timestamp}_${Date.now().toString().slice(-4)}.${ext}`;

      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);

      showToast(t("download_success"), "🎉");
    } catch (e) {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.download = isVideo ? "instagram_video.mp4" : "instagram_photo.jpg";
      document.body.appendChild(a);
      a.click();
      a.remove();
      showToast(t("download_failed"), "🔗");
    }
  }

  function attachDownloadButtons() {
    if (!window.__GHOSTGRAM_CONFIG__.enableDownloader) {
      document.querySelectorAll('.gg-dl-btn').forEach(b => b.remove());
      return;
    }

    const containers = document.querySelectorAll('article, div[role="dialog"] div[style*="aspect-ratio"], div._aagv, div._aagu, div[role="presentation"]');
    containers.forEach(container => {
      if (container.querySelector('.gg-dl-btn')) return;
      const media = container.querySelector('img, video');
      if (!media) return;

      const style = window.getComputedStyle(container);
      if (style.position === 'static') {
        container.style.position = 'relative';
      }

      const dlBtn = document.createElement('button');
      dlBtn.className = 'gg-dl-btn';
      dlBtn.title = t("download_btn_tip");
      dlBtn.innerHTML = `
        <svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:white;">
          <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
        </svg>
      `;
      dlBtn.style.cssText = `
        position: absolute;
        top: 12px;
        right: 12px;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: rgba(18, 18, 24, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.25);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 100;
        opacity: 0;
        transform: scale(0.9);
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        backdrop-filter: blur(8px);
      `;

      container.addEventListener('mouseenter', () => {
        dlBtn.style.opacity = '1';
        dlBtn.style.transform = 'scale(1)';
      });
      container.addEventListener('mouseleave', () => {
        dlBtn.style.opacity = '0';
        dlBtn.style.transform = 'scale(0.9)';
      });

      dlBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        const vid = container.querySelector('video');
        if (vid) {
          downloadMedia(getBestVideoUrl(vid), true);
        } else {
          const img = container.querySelector('img');
          downloadMedia(getBestImageUrl(img), false);
        }
      });

      container.appendChild(dlBtn);
    });

    attachStoryDownloadButton();
  }

  function attachStoryDownloadButton() {
    if (!window.__GHOSTGRAM_CONFIG__.enableDownloader) {
      document.querySelectorAll('.gg-story-dl-btn').forEach(b => b.remove());
      return;
    }

    const isStories = window.location.pathname.startsWith("/stories") ||
                      document.querySelector('section[role="region"]') ||
                      document.querySelector('div[role="dialog"]');
    if (!isStories) return;

    const headers = document.querySelectorAll('header, div[role="dialog"] header, section[role="region"] header');
    headers.forEach(header => {
      if (header.querySelector('.gg-story-dl-btn')) return;

      const dlBtn = document.createElement('button');
      dlBtn.className = 'gg-story-dl-btn';
      dlBtn.title = t("story_download_btn");
      dlBtn.setAttribute('aria-label', t("story_download_btn"));
      dlBtn.innerHTML = `
        <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:white;display:block;">
          <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
        </svg>
      `;
      dlBtn.style.cssText = `
        background: rgba(0, 0, 0, 0.45);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        margin: 0 6px;
        color: white;
        transition: transform 0.15s, background 0.15s;
        z-index: 999;
        backdrop-filter: blur(8px);
      `;
      dlBtn.onmouseenter = () => { dlBtn.style.transform = 'scale(1.1)'; dlBtn.style.background = 'rgba(255, 45, 85, 0.85)'; };
      dlBtn.onmouseleave = () => { dlBtn.style.transform = 'scale(1)'; dlBtn.style.background = 'rgba(0, 0, 0, 0.45)'; };

      dlBtn.onclick = (e) => {
        e.stopPropagation();
        e.preventDefault();
        downloadActiveStory();
      };

      if (header.lastElementChild) {
        header.insertBefore(dlBtn, header.lastElementChild);
      } else {
        header.appendChild(dlBtn);
      }
    });
  }

  function downloadActiveStory() {
    showToast(t("downloading"), "📥");

    let author = "story";
    const authorLink = document.querySelector('header a[role="link"], header a[href^="/"]');
    if (authorLink) {
      const match = authorLink.getAttribute('href')?.replace(/\//g, '');
      if (match) author = match;
    }

    const videos = document.querySelectorAll('video');
    for (let vid of videos) {
      const rect = vid.getBoundingClientRect();
      if (rect.width > 120 && rect.height > 120 && rect.top >= -50 && rect.left >= -50) {
        const url = getBestVideoUrl(vid);
        if (url) {
          downloadMediaWithFilename(url, true, `GhostGram_${author}_${Date.now()}.mp4`);
          return;
        }
      }
    }

    const imgs = document.querySelectorAll('img[srcset], img[decoding="sync"], section img, div[role="dialog"] img');
    let bestImg = null;
    let maxArea = 0;
    imgs.forEach(img => {
      const rect = img.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area > maxArea && rect.height > 200 && rect.width > 200) {
        maxArea = area;
        bestImg = img;
      }
    });

    if (bestImg) {
      const url = getBestImageUrl(bestImg);
      if (url) {
        downloadMediaWithFilename(url, false, `GhostGram_${author}_${Date.now()}.jpg`);
        return;
      }
    }

    showToast(isZh() ? "⚠️ 找不到目前限動媒體" : "⚠️ Story media not found", "⚠️");
  }

  async function downloadMediaWithFilename(url, isVideo, filename) {
    if (!url) return;
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);

      showToast(t("download_success"), "🎉");
    } catch (e) {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      showToast(t("download_failed"), "🔗");
    }
  }

  // 11. Network Interceptors (fetch, XMLHttpRequest, sendBeacon, WebSocket)
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const info = inspectRequest(args[0], args[1]);

    // Track HD MP4 video streams
    if (info.url && (info.url.includes('.mp4') || info.url.includes('/v/t50.') || info.url.includes('/v/t64.'))) {
      window.__lastFetchedVideoUrl = info.url;
    }

    const check = shouldBlockSeen(info);
    if (check.block) {
      recordBlock(check.type, check.label);
      return new Response(JSON.stringify({ data: {}, status: "ok" }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }

    return origFetch.apply(this, args);
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__gg_url = url;
    this.__gg_method = method;
    this.__gg_headers = {};
    return origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (header, value) {
    if (!this.__gg_headers) this.__gg_headers = {};
    this.__gg_headers[header] = value;
    return origSetHeader.apply(this, [header, value]);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const info = inspectRequest(this.__gg_url, {
      method: this.__gg_method,
      headers: this.__gg_headers,
      body: body
    });

    if (info.url && (info.url.includes('.mp4') || info.url.includes('/v/t50.') || info.url.includes('/v/t64.'))) {
      window.__lastFetchedVideoUrl = info.url;
    }

    const check = shouldBlockSeen(info);
    if (check.block) {
      recordBlock(check.type, check.label);

      Object.defineProperty(this, "status", { value: 200, writable: true, configurable: true });
      Object.defineProperty(this, "statusText", { value: "OK", writable: true, configurable: true });
      Object.defineProperty(this, "responseText", { value: JSON.stringify({ data: {}, status: "ok" }), writable: true, configurable: true });
      Object.defineProperty(this, "response", { value: JSON.stringify({ data: {}, status: "ok" }), writable: true, configurable: true });
      Object.defineProperty(this, "readyState", { value: 4, writable: true, configurable: true });

      setTimeout(() => {
        if (typeof this.onreadystatechange === "function") this.onreadystatechange(new Event("readystatechange"));
        if (typeof this.onload === "function") this.onload(new Event("load"));
        if (typeof this.onloadend === "function") this.onloadend(new Event("loadend"));
        this.dispatchEvent(new Event("readystatechange"));
        this.dispatchEvent(new Event("load"));
        this.dispatchEvent(new Event("loadend"));
      }, 0);
      return;
    }

    return origSend.apply(this, [body]);
  };

  // Intercept navigator.sendBeacon
  if (navigator && navigator.sendBeacon) {
    const origSendBeacon = navigator.sendBeacon;
    navigator.sendBeacon = function (url, data) {
      const info = inspectRequest(url, { body: data });
      const check = shouldBlockSeen(info);
      if (check.block) {
        recordBlock(check.type, check.label);
        return true;
      }
      return origSendBeacon.apply(this, arguments);
    };
  }

  // Intercept WebSocket frames (MQTT real-time activity)
  if (window.WebSocket) {
    const origWsSend = WebSocket.prototype.send;
    WebSocket.prototype.send = function (data) {
      if (window.__GHOSTGRAM_CONFIG__.ghostDm) {
        try {
          let text = "";
          if (typeof data === "string") {
            text = data;
          } else if (data instanceof ArrayBuffer) {
            text = new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(data));
          } else if (ArrayBuffer.isView(data)) {
            text = new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
          }
          if (text) {
            if (text.includes("typing_activity") || text.includes("useIGDMarkThreadAsRead") || text.includes("mark_seen")) {
              recordBlock("dm", "實時輸入/已讀狀態信號 (MQTT)");
              return;
            }
          }
        } catch (_) {}
      }
      return origWsSend.apply(this, arguments);
    };
  }

  // 12. Mutation Observer & Periodic Cleaners (Throttled & Non-Recursive)
  let cleanDebounceTimer = null;
  let isExecutingCleaners = false;

  function runCleanersSafely() {
    if (isExecutingCleaners) return;
    isExecutingCleaners = true;
    try {
      cleanAdsAndSuggestions();
      applyDefaultMute();
      attachDownloadButtons();
    } catch (_) {}
    finally {
      isExecutingCleaners = false;
    }
  }

  const observer = new MutationObserver((mutations) => {
    if (isExecutingCleaners) return;

    let hasRelevantMutation = false;
    for (let i = 0; i < mutations.length; i++) {
      const target = mutations[i].target;
      if (target && target.nodeType === 1) {
        const id = target.id || "";
        const cl = target.className || "";
        if (id.startsWith("ghostgram") || (typeof cl === "string" && cl.includes("gg-"))) {
          continue;
        }
      }
      hasRelevantMutation = true;
      break;
    }

    if (!hasRelevantMutation) return;

    if (cleanDebounceTimer) clearTimeout(cleanDebounceTimer);
    cleanDebounceTimer = setTimeout(runCleanersSafely, 300);
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener("DOMContentLoaded", () => {
      if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  setInterval(runCleanersSafely, 2500);

  // 13. UI Construction (Draggable FAB & Modern Control Panel)
  function initUI() {
    if (document.getElementById("ghostgram-fab")) return;

    const btn = document.createElement("div");
    btn.id = "ghostgram-fab";
    btn.style.cssText = `
      position: fixed;
      bottom: 40px;
      right: 40px;
      width: 54px;
      height: 54px;
      border-radius: 50%;
      background: linear-gradient(135deg, #FF2D55 0%, #E1306C 50%, #F77737 100%);
      box-shadow: 0 8px 24px rgba(225, 48, 108, 0.45), 0 2px 8px rgba(0,0,0,0.25);
      cursor: pointer;
      z-index: 2147483646;
      display: ${window.__GHOSTGRAM_CONFIG__.showFab ? "flex" : "none"};
      align-items: center;
      justify-content: center;
      user-select: none;
      touch-action: none;
      transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease;
    `;
    btn.innerHTML = `
      <svg style="width:28px;height:28px;fill:white;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.2));" viewBox="0 0 24 24">
        <path d="M12 2C7.58 2 4 5.58 4 10v9.5c0 .69.69 1.15 1.31.84L7.5 19.3l2.19 1.04c.4.19.88.19 1.28 0l2.03-.97 2.03.97c.4.19.88.19 1.28 0l2.19-1.04 2.19 1.04c.62.31 1.31-.15 1.31-.84V10c0-4.42-3.58-8-8-8zm-2.5 10c-.83 0-1.5-.67-1.5-1.5S8.67 9 9.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm5 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
      </svg>
      <div id="ghostgram-badge" style="position:absolute;top:-4px;right:-4px;background:#10B981;color:white;font-size:10px;font-weight:700;padding:2px 6px;border-radius:10px;border:2px solid #fff;display:none;box-shadow:0 2px 6px rgba(0,0,0,0.2);">0</div>
    `;

    const panel = document.createElement("div");
    panel.id = "ghostgram-panel";
    panel.style.cssText = `
      position: fixed;
      bottom: 105px;
      right: 40px;
      width: 360px;
      max-width: calc(100vw - 24px);
      box-sizing: border-box !important;
      max-height: 560px;
      overflow-y: auto;
      background: rgba(20, 20, 26, 0.97);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 24px;
      padding: 20px;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.75), 0 0 30px rgba(225, 48, 108, 0.15);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 2147483646;
      display: none;
    `;

    function renderPanel() {
      const c = window.__GHOSTGRAM_CONFIG__;
      const isAnyActive = c.ghostStories || c.ghostDm || c.blockAds;

      panel.innerHTML = `
        <style>
          .gg-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            cursor: pointer;
            user-select: none;
            flex-shrink: 0;
            margin: 0;
          }
          .gg-switch input {
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
            margin: 0;
            pointer-events: none;
          }
          .gg-slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background: #33333d;
            border-radius: 24px;
            transition: background 0.25s ease;
          }
          .gg-slider::before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
            transition: transform 0.25s cubic-bezier(0.34, 1.4, 0.64, 1);
          }
          .gg-switch input:checked + .gg-slider {
            background: var(--gg-color, #10B981);
          }
          .gg-switch input:checked + .gg-slider::before {
            transform: translateX(20px);
          }
        </style>

        <div id="gg-panel-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;cursor:grab;user-select:none;padding-bottom:2px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div id="gg-status-dot" style="width:10px;height:10px;border-radius:50%;background:${isAnyActive ? '#10B981' : '#EF4444'};box-shadow:0 0 8px ${isAnyActive ? '#10B981' : '#EF4444'};flex-shrink:0;"></div>
            <span style="font-weight:700;font-size:15px;letter-spacing:0.3px;">${t("title")}</span>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="gg-lang-btn" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.18);color:#ddd;cursor:pointer;font-size:11px;font-weight:600;padding:3px 8px;border-radius:8px;transition:all 0.2s;">
              ${c.language === 'en' ? '中文' : 'EN'}
            </button>
            <button id="gg-close-btn" title="關閉 (Esc)" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;cursor:pointer;font-size:13px;font-weight:700;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:all 0.2s;flex-shrink:0;">✕</button>
          </div>
        </div>

        <!-- Section: 隱身與防已讀 -->
        <div style="font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px;">${t("sec_stealth")}</div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px;">
          <!-- 🟣 隱身看限動 -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.04);border-radius:12px;">
            <div>
              <div style="font-size:12px;font-weight:600;">${t("ghost_stories")}</div>
              <div style="font-size:10px;color:#aaa;">${t("ghost_stories_sub")}</div>
            </div>
            <label class="gg-switch" style="--gg-color:#A855F7;">
              <input type="checkbox" id="gg-stories-toggle" ${c.ghostStories ? 'checked' : ''}>
              <span class="gg-slider"></span>
            </label>
          </div>

          <!-- 🔵 防訊息已讀 -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.04);border-radius:12px;">
            <div>
              <div style="font-size:12px;font-weight:600;">${t("ghost_dm")}</div>
              <div style="font-size:10px;color:#aaa;">${t("ghost_dm_sub")}</div>
            </div>
            <label class="gg-switch" style="--gg-color:#38BDF8;">
              <input type="checkbox" id="gg-dm-toggle" ${c.ghostDm ? 'checked' : ''}>
              <span class="gg-slider"></span>
            </label>
          </div>
        </div>

        <!-- Section: 瀏覽增強功能 -->
        <div style="font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px;">${t("sec_enhanced")}</div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px;">
          <!-- 🟢 去除廣告與推薦 -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.04);border-radius:12px;">
            <div>
              <div style="font-size:12px;font-weight:600;">${t("block_ads")}</div>
              <div style="font-size:10px;color:#aaa;">${t("block_ads_sub")}</div>
            </div>
            <label class="gg-switch" style="--gg-color:#10B981;">
              <input type="checkbox" id="gg-ads-toggle" ${c.blockAds ? 'checked' : ''}>
              <span class="gg-slider"></span>
            </label>
          </div>

          <!-- 🔇 影片與限動預設靜音 -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.04);border-radius:12px;">
            <div>
              <div style="font-size:12px;font-weight:600;">${t("default_mute")}</div>
              <div style="font-size:10px;color:#aaa;">${t("default_mute_sub")}</div>
            </div>
            <label class="gg-switch" style="--gg-color:#F59E0B;">
              <input type="checkbox" id="gg-mute-toggle" ${c.defaultMute ? 'checked' : ''}>
              <span class="gg-slider"></span>
            </label>
          </div>

          <!-- 📥 高清圖片/影片/限動快捷下載 -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,0.04);border-radius:12px;">
            <div>
              <div style="font-size:12px;font-weight:600;">${t("downloader")}</div>
              <div style="font-size:10px;color:#aaa;">${t("downloader_sub")}</div>
            </div>
            <label class="gg-switch" style="--gg-color:#EC4899;">
              <input type="checkbox" id="gg-dl-toggle" ${c.enableDownloader ? 'checked' : ''}>
              <span class="gg-slider"></span>
            </label>
          </div>
        </div>

        <!-- 數據統計 -->
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:14px;">
          <div style="background:rgba(255,255,255,0.04);border-radius:10px;padding:8px 4px;text-align:center;">
            <div style="font-size:10px;color:#888;">${t("stat_story")}</div>
            <div style="font-size:15px;font-weight:700;color:#A855F7;" id="gg-stat-story">${c.storyBlocked || 0}</div>
          </div>
          <div style="background:rgba(255,255,255,0.04);border-radius:10px;padding:8px 4px;text-align:center;">
            <div style="font-size:10px;color:#888;">${t("stat_dm")}</div>
            <div style="font-size:15px;font-weight:700;color:#38BDF8;" id="gg-stat-dm">${c.dmBlocked || 0}</div>
          </div>
          <div style="background:rgba(255,255,255,0.04);border-radius:10px;padding:8px 4px;text-align:center;">
            <div style="font-size:10px;color:#888;">${t("stat_ads")}</div>
            <div style="font-size:15px;font-weight:700;color:#10B981;" id="gg-stat-ads">${c.adsBlocked || 0}</div>
          </div>
        </div>

        <div style="text-align:center;font-size:10px;color:#666;">
          GhostGram v1.3 • ${isZh() ? '由' : 'By'} <a href="https://kkleon.com" target="_blank" style="color:#FF2D55;text-decoration:none;">Kai Liu</a> ${isZh() ? '開發' : 'Dev'}
        </div>
      `;

      function updateHeaderStatus() {
        const anyActive = window.__GHOSTGRAM_CONFIG__.ghostStories || window.__GHOSTGRAM_CONFIG__.ghostDm || window.__GHOSTGRAM_CONFIG__.blockAds;
        const dot = document.getElementById("gg-status-dot");
        if (dot) {
          dot.style.background = anyActive ? '#10B981' : '#EF4444';
          dot.style.boxShadow = `0 0 8px ${anyActive ? '#10B981' : '#EF4444'}`;
        }
      }

      // Event Listeners
      const closeBtn = document.getElementById("gg-close-btn");
      if (closeBtn) {
        closeBtn.onclick = (e) => {
          e.stopPropagation();
          panel.style.display = "none";
        };
      }

      const langBtn = document.getElementById("gg-lang-btn");
      if (langBtn) {
        langBtn.onclick = (e) => {
          e.stopPropagation();
          window.__GHOSTGRAM_CONFIG__.language = window.__GHOSTGRAM_CONFIG__.language === "en" ? "zh" : "en";
          saveConfig();
          renderPanel();
          attachDownloadButtons();
          updateBadge();
        };
      }

      document.getElementById("gg-stories-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.ghostStories = e.target.checked;
        saveConfig();
        updateHeaderStatus();
        showToast(window.__GHOSTGRAM_CONFIG__.ghostStories ? (isZh() ? "限動隱身已啟用" : "Story Ghost Enabled") : (isZh() ? "限動隱身已關閉" : "Story Ghost Disabled"), "🟣");
      };

      document.getElementById("gg-dm-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.ghostDm = e.target.checked;
        saveConfig();
        updateHeaderStatus();
        showToast(window.__GHOSTGRAM_CONFIG__.ghostDm ? (isZh() ? "私訊防已讀已啟用" : "Unseen DMs Enabled") : (isZh() ? "私訊防已讀已關閉" : "Unseen DMs Disabled"), "🔵");
      };

      document.getElementById("gg-ads-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.blockAds = e.target.checked;
        saveConfig();
        cleanAdsAndSuggestions();
        updateHeaderStatus();
        showToast(window.__GHOSTGRAM_CONFIG__.blockAds ? (isZh() ? "廣告過濾已啟用" : "AdBlock Enabled") : (isZh() ? "廣告過濾已關閉" : "AdBlock Disabled"), "🟢");
      };

      document.getElementById("gg-mute-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.defaultMute = e.target.checked;
        saveConfig();
        applyDefaultMute();
        showToast(window.__GHOSTGRAM_CONFIG__.defaultMute ? (isZh() ? "影音預設靜音已開啟" : "Default Mute Enabled") : (isZh() ? "預設靜音已關閉" : "Default Mute Disabled"), "🔇");
      };

      document.getElementById("gg-dl-toggle").onchange = (e) => {
        window.__GHOSTGRAM_CONFIG__.enableDownloader = e.target.checked;
        saveConfig();
        attachDownloadButtons();
        showToast(window.__GHOSTGRAM_CONFIG__.enableDownloader ? (isZh() ? "高清下載已啟用" : "Downloader Enabled") : (isZh() ? "高清下載已關閉" : "Downloader Disabled"), "📥");
      };
    }

    function updatePanelPosition() {
      const rect = btn.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const panelWidth = Math.min(360, vw - 24);

      panel.style.width = `${panelWidth}px`;

      let left = rect.right - panelWidth;
      if (left + panelWidth > vw - 12) left = vw - panelWidth - 12;
      if (left < 12) left = 12;

      panel.style.visibility = "hidden";
      panel.style.display = "block";
      const panelHeight = panel.offsetHeight || 500;
      panel.style.visibility = "visible";

      let top = rect.top - panelHeight - 12;
      if (top < 12) top = rect.bottom + 12;
      if (top + panelHeight > vh - 12) top = vh - panelHeight - 12;
      if (top < 12) top = 12;

      panel.style.bottom = "auto";
      panel.style.right = "auto";
      panel.style.left = `${left}px`;
      panel.style.top = `${top}px`;
    }

    // Draggable header
    let isPanelDragging = false;
    let pStartX, pStartY, pInitialX, pInitialY;
    panel.addEventListener("mousedown", (e) => {
      const header = document.getElementById("gg-panel-header");
      if (!header || !header.contains(e.target) || e.target.id === "gg-close-btn" || e.target.id === "gg-lang-btn") return;
      isPanelDragging = true;
      header.style.cursor = "grabbing";
      pStartX = e.clientX;
      pStartY = e.clientY;
      const pRect = panel.getBoundingClientRect();
      pInitialX = pRect.left;
      pInitialY = pRect.top;

      function onPanelMouseMove(moveEvent) {
        if (!isPanelDragging) return;
        const dx = moveEvent.clientX - pStartX;
        const dy = moveEvent.clientY - pStartY;
        let nLeft = pInitialX + dx;
        let nTop = pInitialY + dy;
        nLeft = Math.max(8, Math.min(window.innerWidth - panel.offsetWidth - 8, nLeft));
        nTop = Math.max(8, Math.min(window.innerHeight - panel.offsetHeight - 8, nTop));
        panel.style.left = `${nLeft}px`;
        panel.style.top = `${nTop}px`;
      }

      function onPanelMouseUp() {
        isPanelDragging = false;
        if (header) header.style.cursor = "grab";
        document.removeEventListener("mousemove", onPanelMouseMove);
        document.removeEventListener("mouseup", onPanelMouseUp);
      }

      document.addEventListener("mousemove", onPanelMouseMove);
      document.addEventListener("mouseup", onPanelMouseUp);
    });

    // Draggable button
    let isDragging = false;
    let startX, startY, initialX, initialY;

    btn.addEventListener("mousedown", (e) => {
      isDragging = false;
      startX = e.clientX;
      startY = e.clientY;
      const rect = btn.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;

      function onMouseMove(moveEvent) {
        const dx = moveEvent.clientX - startX;
        const dy = moveEvent.clientY - startY;
        if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
          isDragging = true;
          btn.style.right = "auto";
          btn.style.bottom = "auto";
          btn.style.left = `${initialX + dx}px`;
          btn.style.top = `${initialY + dy}px`;
          if (panel.style.display === "block") {
            updatePanelPosition();
          }
        }
      }

      function onMouseUp() {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      }

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    });

    btn.addEventListener("click", () => {
      if (!isDragging) {
        if (panel.style.display === "none" || panel.style.display === "") {
          renderPanel();
          panel.style.display = "block";
          updatePanelPosition();
        } else {
          panel.style.display = "none";
        }
      }
    });

    document.addEventListener("mousedown", (e) => {
      if (panel.style.display === "block") {
        if (!panel.contains(e.target) && !btn.contains(e.target)) {
          panel.style.display = "none";
        }
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && panel.style.display === "block") {
        panel.style.display = "none";
      }
    });

    if (document.body) {
      document.body.appendChild(btn);
      document.body.appendChild(panel);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        if (document.body) {
          document.body.appendChild(btn);
          document.body.appendChild(panel);
        }
      });
    }

    updateBadge();
  }

  function updateBadge() {
    const total = (window.__GHOSTGRAM_CONFIG__.storyBlocked || 0) + (window.__GHOSTGRAM_CONFIG__.dmBlocked || 0);
    const badge = document.getElementById("ghostgram-badge");
    if (badge) {
      badge.textContent = total;
      badge.style.display = total > 0 ? "block" : "none";
    }
    const statStory = document.getElementById("gg-stat-story");
    const statDm = document.getElementById("gg-stat-dm");
    const statAds = document.getElementById("gg-stat-ads");
    if (statStory) statStory.textContent = `${window.__GHOSTGRAM_CONFIG__.storyBlocked || 0}`;
    if (statDm) statDm.textContent = `${window.__GHOSTGRAM_CONFIG__.dmBlocked || 0}`;
    if (statAds) statAds.textContent = `${window.__GHOSTGRAM_CONFIG__.adsBlocked || 0}`;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initUI);
  } else {
    initUI();
  }
})();
